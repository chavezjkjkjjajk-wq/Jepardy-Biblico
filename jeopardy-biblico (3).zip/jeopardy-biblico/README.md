# Jeopardy-Biblico

A Pen created on CodePen.

Original URL: [https://codepen.io/Isaac-Chavez-the-sasster/pen/YPWmLBB](https://codepen.io/Isaac-Chavez-the-sasster/pen/YPWmLBB).

